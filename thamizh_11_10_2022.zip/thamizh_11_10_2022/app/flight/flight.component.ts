import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrls: ['./flight.component.css']
})
export class FlightComponent implements OnInit {

  username="jas"
  pass="123456"

  constructor() { }

  ngOnInit(): void {
  }

 

}
