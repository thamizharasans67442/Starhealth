import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airport',
  templateUrl: './airport.component.html',
  styleUrls: ['./airport.component.css']
})
export class AirportComponent implements OnInit {

  airportName= "Chennai International Airport"
  airportCity="Chennai"
  airportNo=1212121212

  constructor() { }

  ngOnInit(): void {
  }

}
